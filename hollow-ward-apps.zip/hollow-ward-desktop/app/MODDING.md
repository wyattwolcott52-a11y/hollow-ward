# Modding The Hollow Ward

Open **Extras > Mods**. You can import a file, paste JSON or an `HWM1-` code, export a mod to share, and turn mods on or off. Mods are stored on the device. Use **Save Example Mod** (or `mods/example.hwmod.json`) as a template.

A mod is one JSON object. Every field except `name` is optional.

```json
{
  "id": "my-mod", "name": "My Mod", "version": "1.0", "author": "You", "description": "Short text",
  "levelMode": "append",
  "levels": [ { "name": "...", "intro": "...", "mz": 10, "fuses": 4, "bats": 6, "drain": 1.5,
                "speed": 1, "amb": 70, "blackouts": false, "seed": 0,
                "monsters": ["lurker", "stalker", "howler"] } ],
  "monsters": { "lurker": { "speed": 100, "sight": 240, "hear": 0.6, "give": 6, "r": 11, "blind": false } },
  "colors": { "game": { "bone": "#e8e0cf", "blood": "#9c1c1c", "amber": "#ffb347", "dim": "#7d786a", "sick": "#9fb38a" },
              "ui": { "red": "#ec3a3c", "redInk": "#3d070c", "bone": "#d6d0ca", "dim": "#8d8782", "head": "#efe9e2", "green": "#3ec957", "amber": "#ffb347" } },
  "sprites": { "player": "data:image/png;base64,...", "lurker": "data:image/png;base64,..." },
  "script": "game.on('fuse', function () { game.giveBattery(10); });"
}
```

## Levels
`levelMode` is `append` (after the five built-in levels, before the endless ones) or `replace` (replaces the whole built-in campaign). Limits: 50 levels, map size `mz` 6 to 30, fuses 1 to 15, batteries 0 to 20, drain 0.5 to 3, speed 0.6 to 1.4, visibility `amb` 30 to 130, up to 40 monsters. A `seed` above 0 makes the maze the same every time.

## Monsters
Stats can be changed for `lurker`, `stalker` and `howler`. To add new monsters, see **Custom monsters** below.

## Art
Sprites are PNG or WebP data URLs under about 700 KB, and each sheet must keep the original layout.
- `player`: 316x412, a 4x4 grid of 79x103 frames. Rows are down, right, left, up. Columns are walk frames.
- `lurker`, `stalker`, `howler`: 296x270 with 37x45 cells, 8 frames per row. Rows are idle, walk, chase, then three glow layers (same order) used for the red wounds.

Mod art replaces the built-in sheet, so the Character and Monster colour pickers do not recolour it.

## Scripts
Scripts run when a mod is loaded, with `game` and `mod` in scope. **A script can do anything the game page can, so only install scripts you trust.** The game asks before installing a mod that has one. A handler that throws three times is switched off.

Events, registered with `game.on(name, fn)`: `levelStart`, `tick(dt)`, `fuse(fuse)`, `battery(battery)`, `death(monster)`, `win`.

API: `game.player`, `game.monsters`, `game.level` (editable, e.g. `game.level.drain`), `game.time`, `game.state`, `game.tile`, `game.toast(text, seconds)`, `game.tone(freq, dur, type, vol)`, `game.alert(x, y, radius)`, `game.giveBattery(n)`, `game.spawn(type, x, y)`, `game.random(a, b)`.

## Mod Library
Open **Extras > Mod Library** (or **Mods > Mod Library**). It ships with 24 ready-made mods in five categories. Pick a mod to **Install** it, turn it **On/Off**, **Download File**, or **Copy Code**. **Download Pack** saves a whole category (or everything) as one file, and importing a pack installs every mod in it. **Download Separately** saves one file per mod.

The same files are in the `mods/` folder of this app: one `.hwmod.json` per mod, plus `all-mods.hwmodpack.json`.

Difficulty: Nightmare, Gentle Ward, Blind Hunters, Museum Mode, Total Darkness.
Gameplay: Proximity Sensor, Loud Fuses, Rising Dread, Breeding Ground, Haunted Whispers.
Levels: Deep Wing (6 floors, appended), Gauntlet (5 fixed-map floors, **replaces** the campaign), Howler Choir (3 floors), Closet Floors (4 tiny floors).
Monsters: Wraith Wing, Brute Force, Crawler Nest, Siren Song, Menagerie, Uninvited Guest (each adds new monster types).
Looks: Blood Moon, Toxic Ward, Old Film, Ice Ward.

Mods stack in install order, so Nightmare and Gentle Ward together will fight each other. Turn one off.

## Packs
A pack is a JSON file shaped like `{ "format": "hollow-ward-modpack", "name": "My Pack", "mods": [ {mod}, {mod} ] }`. A plain JSON array of mods also works.

## Custom monsters
Add up to 12 new monster types per mod with `customMonsters`, then use their ids in a level's `monsters` list or with `game.spawn(id, x, y)`.

```json
"customMonsters": {
  "ghoul": { "name": "Ghoul", "base": "lurker", "speed": 120, "sight": 280, "hear": 0.8,
            "give": 6, "r": 12, "blind": false, "scale": 1.3,
            "body": "#5f7a3a", "marks": "#40ff70", "eyes": "#46ff6e" }
}
```
- `id` (the key): lowercase letters, digits, `-` and `_`, up to 24 characters, and not `lurker`, `stalker` or `howler`.
- `base`: `lurker`, `stalker` or `howler`. This sets how it behaves. A stalker-based monster still freezes in your light, a howler-based one still hunts by sound, and the audio cues match the base. Stats you leave out come from the base.
- Stats: `speed` 20 to 300, `sight` 0 to 800, `hear` 0 to 3, `give` 1 to 30, `r` 6 to 20, `blind` true or false.
- Looks: `scale` 0.5 to 2.2, `body` and `marks` as `#rrggbb` (recolours the stock art), `eyes` as `#rrggbb`. Or give a `sprite` PNG data URL with the same 296x270 layout as the monster sheets, which replaces the recolour.
- Levels can only use custom monsters defined in the same mod. A script can spawn them in any level, as the Uninvited Guest mod does.

**Mods > Save Monster Template** downloads a ready-to-edit example (also `mods/example-monster.hwmod.json`).
