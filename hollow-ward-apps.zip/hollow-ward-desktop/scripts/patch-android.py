# Run after `npx cap add android`: lock landscape, hide system bars, and cover display cutouts.
import re, pathlib
root = pathlib.Path("android/app/src/main")
mf = root / "AndroidManifest.xml"
t = mf.read_text()
if "screenOrientation" not in t:
    t = t.replace("<activity", '<activity android:screenOrientation="sensorLandscape"', 1)
mf.write_text(t)
st = root / "res/values/styles.xml"
s = st.read_text()
items = ('<item name="android:windowFullscreen">true</item>\n'
         '        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>\n'
         '        <item name="android:windowBackground">@android:color/black</item>\n')
s = re.sub(r'(<style name="AppTheme.NoActionBar"[^>]*>)', lambda m: m.group(1) + "\n        " + items, s, 1)
st.write_text(s)
# Immersive mode: hide status/navigation bars while the game is in front.
ja = next(root.glob("java/**/MainActivity.java"))
j = ja.read_text()
if "WindowInsetsControllerCompat" not in j:
    j = j.replace("import com.getcapacitor.BridgeActivity;",
      "import android.os.Bundle;\nimport androidx.core.view.WindowCompat;\nimport androidx.core.view.WindowInsetsControllerCompat;\nimport androidx.core.view.WindowInsetsCompat;\nimport com.getcapacitor.BridgeActivity;")
    j = re.sub(r"public class MainActivity extends BridgeActivity \{\s*\}",
      """public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        hideBars();
    }
    @Override
    public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }
    private void hideBars() {
        WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        c.hide(WindowInsetsCompat.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}""", j)
    ja.write_text(j)
print("patched")
